<div class="col-md-12">
    <iframe width="1100" height="1750" src="https://datastudio.google.com/embed/reporting/1NmUkehqtxvluP0HpeddRiOEvsSaR9-Bs/page/1M" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>